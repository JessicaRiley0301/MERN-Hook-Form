import React, { useState } from  'react';
    
    
const UserForm = (props) => {
    const [firstname, setFirstname] = useState("");
    const [lastname, setLastname] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");  
    const [confirmpassword, setConfirmPassword] = useState("");  



    const [nameError, setNameErr] = useState("");
    const [emailError, setEmailErr] = useState("");
    const [passwordError, setPasswordErr] = useState("");
    const [confirmpasswordError, setConfirmPasswordErr] = useState("");

    // const [user, setUser] = useState({});

    const createUser = (e) => {
        e.preventDefault();
        const newUser = { firstname, lastname, email, password, confirmpassword };
        console.log("Welcome", newUser);
    };

    // props.addNewUser(newUser);

    const checkLength = (aString) => {
        console.log(aString);

        // set to state to save the string
        setFirstname(aString);
        setLastname(aString);

        // check errors
        if (aString.length < 2) {
            setNameErr("must be longer than 3 chars")
        }
        else if (aString === "" ){
            setNameErr("at least put something here 🙃");
        }
        else {
            // else clear the input 
            setNameErr("")
        }
    }
    const checkLength2 = (aString) => {
        console.log(aString);

        // set to state to save the string
        setEmail(aString);

        // check errors
        if (aString.length < 5) {
            setEmailErr("must be longer than 5 chars")
        }
        else if (aString === "" ){
            setEmailErr("at least put something here 🙃");
        }
        else {
            // else clear the input 
            setEmailErr("")
        }
    }

    const checkPasswordLength = (aString) => {
        console.log(aString);

        // set to state to save the string
        setPassword(aString);
        setConfirmPassword(aString);
        // console.log(aString.target.value)

        if (aString !== confirmpassword) {
            setConfirmPasswordErr("password must match")
        }        else if (aString === "" ){
            setConfirmPasswordErr("at least put something here 🙃");
        }
        else {
            // else clear the input 
            setConfirmPasswordErr("")
        }
        // check errors

        // else if (aString === "" ){
        //     setPasswordErr("at least put something here 🙃");
        // }
        // else {
        //     // else clear the input 
        //     setPasswordErr("")
        // }
    }

    // const checkPasswordMatch = (aString) => {
    //     console.log(aString);

    //     // set to state to save the string
    //     setPassword(aString);
    //     setConfirmPassword(aString);

    //     // check errors
    //     if (setPassword(aString) !== setConfirmPassword(aString)) {
    //         setConfirmPasswordErr("password must match")
    //         console.log(aString);
    //     }
    //     else if (aString === "" ){
    //         setConfirmPasswordErr("at least put something here 🙃");
    //     }
    //     else {
    //         // else clear the input 
    //         setConfirmPasswordErr("")
    //     }
    // }
    

    
    return(
        <div>
        <form onSubmit={ createUser }>
            <div>
                <label>First name: </label> 
                <input type="text" onChange={ (e) => checkLength(e.target.value) } />
                {nameError ? <span style={{ color: "red" }}>{nameError}</span> : <span>&nbsp;</span>}
            </div>
            <div>
                <label>Last name: </label> 
                <input type="text" onChange={ (e) => checkLength(e.target.value) } />
                {nameError ? <span style={{ color: "red" }}>{nameError}</span> : <span>&nbsp;</span>}
            </div>
            <div>
                <label>Email Address: </label> 
                <input type="text" onChange={ (e) => checkLength2(e.target.value) } />
                {emailError ? <span style={{ color: "red" }}>{emailError}</span> : <span>&nbsp;</span>}
            </div>
            <div>
                <label>Password: </label>
                <input type="password" onChange={ (e) => checkPasswordLength(e.target.value) } />
                {passwordError ? <span style={{ color: "red" }}>{passwordError}</span> : <span>&nbsp;</span>}
            </div>
            <div>
                <label>Confirm Password: </label>
                <input type="password" onChange={ (e) => checkPasswordLength(e.target.value)  } />
                {confirmpasswordError ? <span style={{ color: "red" }}>{confirmpasswordError}</span> : <span>&nbsp;</span>}
            </div>
            <input type="submit" value="Create User" />
        </form>

        <p>Your Form Data</p>
        <p>{JSON.stringify(firstname)}</p>
        <p>{JSON.stringify(lastname)}</p>
        <p>{JSON.stringify(email)}</p>
        <p>{JSON.stringify(password)}</p>
        <p>{JSON.stringify(confirmpassword)}</p>
        </div>
    );
};
    
export default UserForm;